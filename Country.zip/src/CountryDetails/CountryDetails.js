import React from 'react'
import Layout, { Content ,Header} from 'antd/lib/layout/layout'
import {useState , useEffect  } from 'react'
import { Table, Row, Col , Button} from 'antd';
import axios from 'axios';
import {useNavigate } from "react-router-dom";
import {useLocation} from 'react-router-dom';
import MainHeader from '../Header/Header';
const CountryDetails = (props) =>{
    const Header =[
        {
            title:'Common Name',
            dataIndex:'common',
            key:'common'
    
        } ,
        {
            title:'Official Name',
            dataIndex:'official',
            key:'official'
    
        },
        {
            title:'Currencies',
            dataIndex:'currencies',
            key:'currencies'
    
        },
        {
            title:'Languages',
            dataIndex:'languages',
            key:'languages'
    
        },
        {
            title:'Flag',
            dataIndex:'flag',
            key:'flag'
    
        },
    ]
    const [data, setdata] = useState([])
    const [loading, setloading] = useState(true)
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        getData() }
    , [])
    // console.log(props)
    const getData = async () =>{
        const common = location.state.commonName;
        const res = await axios.get(`https://restcountries.com/v3.1/name/${common}`)
        const k = Object.keys(res.data[0].currencies);
        const l = Object.keys(res.data[0].languages);
        // console.log(k)
        setloading(false)
        setdata(  res.data.map(row =>({
        common:row.name.common,official:row.name.official,currencies:row.currencies[k].name + " - " + row.currencies[k].symbol,languages:row.languages[l],flag:row.flag })) );
        // const v = data[0].currencies[k].name
        // console.log(v)
        // const value = res.data.map(row=>({currencies:row.currencies.map(mapvalue)}))
        // const value2 = Object.keys(res.data.currencies)
        // const value3 = value2.map(e=>(e.name))
        // const value2 = res.data.map(e=>e.currencies)
        // console.log(Object.keys(res.data.currencies).map((key,i)=>(res.data.currencies[key])))
        // const value3 = value2.map(p=>p.values)
        // console.log(value2)
        // console.log(JSON.stringify(value2))
        // const value = Object.values(value2)
        // const value3 = Object.values(value)
        // console.log(value3)
        // for (let i=0; i < res.data.length(); i++) {
        //     console.log(res.data.getJSONObject(i));
        // }
    }   
  return (

    <Layout style={{height:"100%"}}>
        <MainHeader/>
        <Content  style={{padding:50}}>
            <Row>
                <Col span={3}/>
                <Col span={18}>
                    <Table dataSource={data} columns={Header} />
                </Col>
                <Col span={3}/>
            </Row>


        </Content>
    </Layout>
  )
}

export default CountryDetails