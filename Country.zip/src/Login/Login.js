import React from "react";
// import { useState, useEffect } from "react";
// import { Layout, Row, Col, Form, Input, Button, Checkbox } from "antd";
import 'antd/dist/antd.css';
import { useState } from "react";
import { LockOutlined, UserOutlined } from '@ant-design/icons';
import { Button, Checkbox, Form, Input } from 'antd';
import { Link, useNavigate } from "react-router-dom";

import "../Components/StyledElements.css"

const validateMessages = {
  required: "This field is required!",
  types: {
    email: "Not a valid email format!",
  },
};
const onFinish = (values) => {
    console.log('Received values of form: ', values);
};

async function loginUser(credentials) {

  return fetch('https://reqres.in/api/login', {
      method: 'POST',
      headers: {
          'Content-Type':'application/json'
      },
      body: JSON.stringify(credentials)
  })
      .then(data => data.json())

}



function Login() {
  
 const [email, setEmail] = useState();
 const [password, setPassword] = useState();
 const [checkbox, setcheckbox] = useState(false);
 const navigate = useNavigate();
 const onChange = () => {
  setcheckbox(true);
};

 const handleSubmit = async e => {
  e.preventDefault();
  const token = await loginUser({
    email,
    password
  });

  if (checkbox == true)
  {
     localStorage.setItem('token', JSON.stringify(token.token));
    //  setEmail('');
    //  setPassword('');
    }
  // else if (checkbox == false){
  //   setEmail('');
  //    setPassword('');
  // }
  if ((token.error == "user not found" || token.error == "Missing email or username")){
    
  alert("Please Enter a valid email ID & Password")
  }
  else{
    navigate("/country-list/")
  }
}
  

  return (
    <div id="login-page" style={{margin: "100px 0px 0px 500px"}}>
      <h1 style={{marginBottom:"3rem"}}>Login To Country List</h1>
    <Form
      name="normal_login"
      className="login-form"
      initialValues={{ remember: true }}
      onFinish={onFinish}
    >
      <Form.Item
        name="username"
        rules={[{ required: true, message: 'Please input your Username!' }]}
      >
        <Input prefix={<UserOutlined className="site-form-item-icon" />} placeholder="Username"  onChange={e=>setEmail(e.target.value)}/>
      </Form.Item>
      <Form.Item
        name="password"
        rules={[{ required: true, message: 'Please input your Password!' }]}
      >
        <Input
          prefix={<LockOutlined className="site-form-item-icon" />}
          type="password"
          placeholder="Password"
          onChange={e=>setPassword(e.target.value)}
        />
      </Form.Item>
      <Form.Item>
        <Form.Item name="remember" valuePropName="unchecked" noStyle>
          <Checkbox onChange={onChange}>Remember me</Checkbox>
        </Form.Item>

        <a className="login-form-forgot" href="">
          Forgot password
        </a>
      </Form.Item>

      <Form.Item>
        <Button type="primary" htmlType="submit" className="login-form-button"onClick={handleSubmit}>
          Log in
        </Button>
        Or <a href="">register now!</a>
      </Form.Item>
    </Form>
    </div>
  );
}

export default Login;
