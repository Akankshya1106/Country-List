import React from 'react'
import {useState , useEffect } from 'react'
import Layout, { Header, Content, Footer } from 'antd/lib/layout/layout'
import Sider from 'antd/lib/layout/Sider'
import { Table, Row, Col , Button } from 'antd';
import axios from 'axios';
import eyevisibleIcon from "../Assets/Icons/eyevisible.svg";
import {useNavigate } from "react-router-dom";
import CountryDetails from '../CountryDetails/CountryDetails';
import MainHeader from '../Header/Header';

const CountryList = () =>{
    const navigate = useNavigate();
    
    
    const [data, setdata] = useState([])
    const [loading, setloading] = useState(true)
    const [tempData, setTempData] = useState([])
    const [value , setValue] = useState()
    
    // setValue(data.map(e=>e.common))
    // console.log(value)
    useEffect(() => {
        getData() }
    , [])

    const getData = async () =>{
        const res = await axios.get('https://restcountries.com/v3.1/all')
        setloading(false)
        setTempData(res.data)
        setdata(  res.data.map(row =>({cca2:row.cca2,common:row.name.common,capital:row.capital })) );
        // setdata(res.data);
        // console.log(res.data)
        
                
    }
    // console.log(tempData)
    const handleSubmit = (c) =>{
        setValue(c.common)
        navigate("country-details",{state : {commonName : c.common}})
        
    }

    const columns =[
        {
            title:'cca2',
            dataIndex:'cca2',
            key:'cca2'
    
        } ,
        {
            title:'common name',
            dataIndex:'common',
            key:'common'
    
        },
        {
            title:'Capital',
            dataIndex:'capital',
            key:'capital'
    
        },
        {
            title: 'Action',
            key: 'action',
            render: (data) => (
              <img src={eyevisibleIcon} alt='eye' width={30} height={20} onClick={() => handleSubmit(data)}/>
            ),
          },    
    ]
  return (
    <Layout>
    <MainHeader></MainHeader>
    
        <Content  style={{padding:50}}>
            <Row>
                <Col span={3}/>
                <Col span={18}>
                    <Table dataSource={data} columns={columns} />
                </Col>
                <Col span={3}/>
            </Row>


        </Content>
    
   <Footer>Footer</Footer>
   
    {/* <CountryDetails common={value}/> */}
   
   
</Layout>
  )
}

export default CountryList