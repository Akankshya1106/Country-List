import React from 'react'
import { Table, Row, Col , Button } from 'antd';
import {useNavigate } from "react-router-dom";
import Layout, { Header, Content, Footer } from 'antd/lib/layout/layout';

const MainHeader = () =>{
    const navigate = useNavigate();
  return (
    <Layout>
    <Header>
        <Row style={{color:"whitesmoke"}}>
            <Col span={12}>
                <a href='/country-list' style={{color:"whitesmoke"}} onClick={()=>navigate("country-list")}> CountryList</a>
            </Col>
            <Col span={12}>
                <Button style={{float:"right" , margin:"16px"}} onClick={()=>navigate("/login")}>
                    Log out
                </Button>
            </Col>
        </Row>
    </Header>
    </Layout>
  )
}

export default MainHeader