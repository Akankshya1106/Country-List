
import CountryList from './CountryLIst/CountryList';
import Login from './Login/Login';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import CountryDetails from './CountryDetails/CountryDetails';


function App() {
  return (
    <div className="App">
      {/* <Login/> */}
      {/* <Navbar/> */}
      {/* <CountryList/> */}
      <BrowserRouter>
      <Routes>
          <Route path="/*" element={<Login />} />
          <Route path="/country-list" element={<CountryList/>}/>
          <Route path="/country-list/country-details" element={<CountryDetails/>}/>
     </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;
